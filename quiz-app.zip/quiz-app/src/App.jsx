import React from "react"
import Quiz from "./components/Quiz/Quiz"
const App = () => {
  return(
    <>

      <Quiz/>

    </>
  )
}
export default App
